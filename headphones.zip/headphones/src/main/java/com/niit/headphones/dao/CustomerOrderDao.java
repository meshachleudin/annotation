package com.niit.headphones.dao;

import com.niit.headphones.model.CustomerOrder;

public interface CustomerOrderDao {

    void addCustomerOrder(CustomerOrder customerOrder);
}
