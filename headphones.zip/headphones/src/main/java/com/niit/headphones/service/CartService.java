package com.niit.headphones.service;

import com.niit.headphones.model.Cart;

public interface CartService {

    Cart getCartById(int cartId);

    void update(Cart cart);
}
